<template>
    <div class="container border-1">
    <div class="row g-2">
    <div class="col">
    <router-link to="/">
    <figure class="figure">
    <img src="./images/3월_서브.jpg" class="custom-image figure-img img-fluid rounded" alt="March">
    <figcaption class="figure-caption text-end">March</figcaption>
    </figure>
    </router-link>
    </div>
    </div>
    </div>
    </template>
    <style>
    .custom-image {
    width: 1200px;
    height: auto;
    max-width: 100%;
    }
    </style>

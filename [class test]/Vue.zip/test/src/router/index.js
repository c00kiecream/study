import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import JanuaryMonth from '../views/JanuaryMonth.vue'
import FebruaryMonth from '../views/FebruaryMonth.vue'
import MarchMonth from '../views/MarchMonth.vue'
import AprilMonth from '../views/AprilMonth.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/JanuaryMonth',
    name: 'JanuaryMonth',
    component: JanuaryMonth
  },
  {
    path: '/FebruaryMonth',
    name: 'FebruaryMonth',
    component: FebruaryMonth
  },
  {
    path: '/MarchMonth',
    name: 'MarchMonth',
    component: MarchMonth
  },
  {
    path: '/AprilMonth',
    name: 'AprilMonth',
    component: AprilMonth
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router

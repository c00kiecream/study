package javacode_김성종;

public class PhoneMain2 {

	public static void main(String[] args) {
		
		SmartPhone sp = new SmartPhone ("Green");
		sp = new SmartPhone("Green");
		sp.getPhone();
		
		sp = new SmartPhone("Pink-Gold", "겔럭시-S22");
		sp.getPhone();
		
		sp= new SmartPhone("Cream", "겔럭시-S22", 2000000);
		sp.getPhone();
		
		SmartPhone2 sp4 = new SmartPhone2();
		
		sp4.setPhone("그라파이트");
		sp4.getPhone();
		
		sp4.setPhone("바이올렛", "겔럭시-S22");
		sp4.getPhone();
		
		sp4.setPhone("스카이블루", "겔럭시-S22 울트라", 3000000);
		sp4.getPhone();

	}

}

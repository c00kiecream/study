package javacode_김성종;

public class SmartPhone extends Phone {
	
	String color;
	String model;
	int price;
	
	SmartPhone(String color){
		super(color);
	}
	SmartPhone(String  color, String model){
		super(color,model);
	}
	SmartPhone(String color, String model, int price){
		super(color, model, price);
		
	}

}

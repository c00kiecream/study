package javacode_김성종;

public class SmartPhone2 extends Phone {

	void set() {
		super.setPhone(color);
		super.setPhone(color, model);
		super.setPhone(color, model, price);
	}
}
